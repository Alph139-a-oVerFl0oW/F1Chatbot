import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    loadComponent: () => import('./dashboard/dashboard').then((m) => m.Dashboard)
  },
  {
    path: 'chat',
    loadComponent: () => import('./chat/chat').then((m) => m.Chat)
  },
  {
    path: 'auth/login',
    loadComponent: () => import('./auth/login/login').then((m) => m.Login)
  },
  { path: '**', redirectTo: '' }
];
