import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';

@Component({
  selector: 'app-nav-bar',
  imports: [RouterLink, RouterLinkActive],
  templateUrl: './nav-bar.html',
  styleUrl: './nav-bar.scss'
})
export class NavBar {
  protected readonly links = [
    { path: '/', label: 'Dashboard' },
    { path: '/chat', label: 'Chatbot' },
    { path: '/auth/login', label: 'Sign in' }
  ];
}
