import { Component } from '@angular/core';

@Component({
  selector: 'app-login',
  template: `
    <section class="placeholder">
      <h1>Sign in</h1>
      <p>JWT auth, route guards, and favorites land in Phase 5.</p>
    </section>
  `,
  styles: [
    `
      .placeholder {
        padding: 2rem 1.5rem;
        max-width: 480px;
        margin: 0 auto;
        color: var(--f1-white-dim);
      }
      h1 {
        font-family: var(--font-display);
        color: var(--f1-white);
      }
    `
  ]
})
export class Login {}
