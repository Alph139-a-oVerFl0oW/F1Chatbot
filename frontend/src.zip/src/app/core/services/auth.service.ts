import { Injectable, signal } from '@angular/core';

/**
 * Placeholder for Phase 5 (Auth + favorites).
 * Will call POST /api/auth/register, /api/auth/login, /api/auth/refresh
 * and store the JWT + expose an authenticated signal for route guards.
 */
@Injectable({ providedIn: 'root' })
export class AuthService {
  readonly isAuthenticated = signal(false);
  private token: string | null = null;

  getToken(): string | null {
    return this.token;
  }
}
